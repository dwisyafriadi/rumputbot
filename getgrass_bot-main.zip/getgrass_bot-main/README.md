# getgrass_bot

`pip3 install websockets_proxy`


`pip3 install loguru`


修改main函数中user_id和sock5代理列表

如果不使用代理,请运行no_proxy.py


### 邀请链接

https://app.getgrass.io/register/?referralCode=0PhrIR8TAQX6IG4

### user_id获取方法

1.打开链接登录https://app.getgrass.io/dashboard

2.页面按F12打开控制台 输入代码

`localStorage.getItem('userId')`

打印的就是当前用户的user_id


![0001](https://github.com/ymmmmmmmm/getgrass_bot/assets/51306299/31d0e16e-df2f-443a-a141-910d16052ed9)


无代码基础请直接使用带界面版本


![3333](https://github.com/ymmmmmmmm/getgrass_bot/assets/51306299/80e18c1f-da5d-40d4-a361-3506b44c6602)


